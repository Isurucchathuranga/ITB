package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class adminLoginActivity extends AppCompatActivity {

    Button btnad;
    EditText username;
    EditText passwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        btnad=findViewById(R.id.btnloginad);
        username=findViewById(R.id.txtusername);
        passwd=findViewById(R.id.txtusepw);

        final String correctusername="Admin";
        final String correctpw="1234";

        btnad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (username.getText().toString().equals(correctusername) && passwd.getText().toString().equals(correctpw)) {
                    //counter--;
                  Intent myIntentt = new Intent(getBaseContext(), adminActivity.class);
                    startActivity(myIntentt);
                    //if (counter==0){
                    // btnad.setEnabled(false)
                } else {
                    Toast.makeText(adminLoginActivity.this, "Unrecognized Admin Login", Toast.LENGTH_LONG).show();
                }
                //Toast.makeText(adminLoginActivity.this, "Unrecognized Admin Login", Toast.LENGTH_LONG).show();
            }
        });

    }
}
