package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class invoiceActivity extends AppCompatActivity {

    TextView amqt, laqt, moqt,eqt,cqt,dqt;
    String am, la, mo,es,co,doo;

    TextView ampr, lapr, mopr,epr,cpr,dpr, total;

    int ame, latt, moc,esp,cu,dop, tot;
    DatabaseHelper mydb;
    Button btnOk,btnout;

    private TextView txtdate;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        mydb = new DatabaseHelper(this);

        amqt = findViewById(R.id.txt_ame_qty);
        laqt = findViewById(R.id.txt_latt_aty);
        moqt = findViewById(R.id.txt_mo_qty);
        eqt = findViewById(R.id.txt_es_qty);
        cqt = findViewById(R.id.txt_cap_qty);
        dqt = findViewById(R.id.txt_do_qty);

        ampr = findViewById(R.id.txt_ame_amt);
        lapr = findViewById(R.id.txt_latt_amt);
        mopr = findViewById(R.id.txt_mo_amt);
        epr = findViewById(R.id.txt_ex_amt);
        cpr = findViewById(R.id.txt_c_amt);
        dpr = findViewById(R.id.txt_do_amt);
        total = findViewById(R.id.txt_total_price);

        am = getIntent().getExtras().getString("Value1");
        la = getIntent().getExtras().getString("Value2");
        mo = getIntent().getExtras().getString("Value3");
        es = getIntent().getExtras().getString("Value4");
        co = getIntent().getExtras().getString("Value5");
        doo = getIntent().getExtras().getString("Value6");

        amqt.setText(am);
        laqt.setText(la);
        moqt.setText(mo);
        eqt.setText(es);
        cqt.setText(co);
        dqt.setText(doo);

        txtdate = (TextView) findViewById(R.id.txtDate);

        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        date = dateFormat.format(calendar.getTime());
        txtdate.setText(date);

        int a = Integer.parseInt(amqt.getText().toString());
        ame = a * 370;
        ampr.setText(String.valueOf("Rs." + ame + "/="));

        int l = Integer.parseInt(laqt.getText().toString());
        latt = l * 440;
        lapr.setText(String.valueOf("Rs." + latt + "/="));

        int m = Integer.parseInt(moqt.getText().toString());
        moc = m * 480;
        mopr.setText(String.valueOf("Rs." + moc + "/="));

        int e = Integer.parseInt(eqt.getText().toString());
        esp = e * 500;
        epr.setText(String.valueOf("Rs." + esp + "/="));

        int c = Integer.parseInt(laqt.getText().toString());
        cu = c * 520;
        cpr.setText(String.valueOf("Rs." + cu + "/="));

        int d = Integer.parseInt(moqt.getText().toString());
        dop = d * 550;
        dpr.setText(String.valueOf("Rs." + dop + "/="));

        tot = ame + latt + moc+esp+cu+dop;
        total.setText(String.valueOf("Rs." + tot + "/="));


        btnOk = findViewById(R.id.btn_ok);
        AddData();

        btnout = findViewById(R.id.btn_logout);
        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getBaseContext(),caffe_Talk_MainActivity.class);
                startActivity(i);
            }
        });

    }

    public void AddData() {
        btnOk.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        boolean isInserted = mydb.saveData(ampr.getText().toString(),
                                lapr.getText().toString(),
                                mopr.getText().toString(),
                                epr.getText().toString(),
                                cpr.getText().toString(),
                                dpr.getText().toString(),
                                total.getText().toString(),
                                txtdate.getText().toString());

                        if (isInserted = true)
                            Toast.makeText(invoiceActivity.this, "Invoice Data Saved", Toast.LENGTH_LONG).show();

                        else
                            Toast.makeText(invoiceActivity.this, "Invoice Data is not Saved", Toast.LENGTH_LONG).show();


                    }
                }
        );

    }
}

