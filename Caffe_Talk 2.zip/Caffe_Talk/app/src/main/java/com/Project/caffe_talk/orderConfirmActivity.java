package com.Project.caffe_talk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class
orderConfirmActivity extends AppCompatActivity {


    TextView txtlocation;

    LocationManager locationManager;
    LocationListener locationListener;

    DatabaseHelper mydb;

    EditText americanoQty,latteQty,mochaQty,exQty,coQty,doQty;
    String am,la,mo,es,co,doo;

    private TextView txtdate;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;

    Button btnConfirm,btnout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirm);


        mydb = new DatabaseHelper(this);

        txtlocation = findViewById(R.id.txtAddress);

        americanoQty = findViewById(R.id.txtAmericanoQty);
        latteQty = findViewById(R.id.txtLatteQty);
        mochaQty = findViewById(R.id.txtMochaQty);
        exQty = findViewById(R.id.txtExcQty);
        coQty = findViewById(R.id.txtCapQty);
        doQty = findViewById(R.id.txtDopQty);

        txtdate = (TextView) findViewById(R.id.txtDate);

        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        date = dateFormat.format(calendar.getTime());
        txtdate.setText(date);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnout = findViewById(R.id.btnOut);
        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getBaseContext(),caffe_Talk_MainActivity.class);
                startActivity(i);
            }
        });

        locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        boolean isGPS_enabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if(isGPS_enabled)
        {
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location)
                {
                    double longitude = location.getLongitude();
                    double latitude = location.getLatitude();

                    try
                    {
                        Geocoder geocoder = new Geocoder(orderConfirmActivity.this, Locale.getDefault());
                        List<Address> addressList = geocoder.getFromLocation(latitude,longitude,1);

                        txtlocation.setText(addressList.get(0).getAddressLine(0));

                    }
                    catch(IOException e)
                    {
                        e.printStackTrace();
                    }


                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            };
        }

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        else
        {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,0,0,locationListener);
        }


        AddData();
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,0,0,locationListener);

                txtlocation.setText("Getting Location Address");
            }
        }
        else
        {
            txtlocation.setText("Access not granted");
        }



    }

    public void AddData()
    {
        btnConfirm.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        final String ameQty = americanoQty.getText().toString();
                        final String latQty = latteQty.getText().toString();
                        final String mocQty = mochaQty.getText().toString();
                        final String eQty = exQty.getText().toString();
                        final String cQty = coQty.getText().toString();
                        final String dQty = doQty.getText().toString();

                        boolean isInserted;
                        if (!ameQty.matches("[0-9]+")) {
                            americanoQty.requestFocus();
                            americanoQty.setError("ENTER NUMBERS ONLY");
                        } else if (!latQty.matches("[0-9]+")) {
                            latteQty.requestFocus();
                            latteQty.setError("ENTER NUMBERS ONLY");
                        } else if (!mocQty.matches("[0-9]+")) {
                            mochaQty.requestFocus();
                            mochaQty.setError("ENTER NUMBERS ONLY");
                        } else if (!eQty.matches("[0-9]+")) {
                            exQty.requestFocus();
                            exQty.setError("ENTER NUMBERS ONLY");
                        } else if (!cQty.matches("[0-9]+")) {
                            coQty.requestFocus();
                            coQty.setError("ENTER NUMBERS ONLY");
                        } else if (!dQty.matches("[0-9]+")) {
                            doQty.requestFocus();
                            doQty.setError("ENTER NUMBERS ONLY");
                        } else {
                            isInserted = mydb.insertData(txtlocation.getText().toString(),
                                    americanoQty.getText().toString(),
                                    latteQty.getText().toString(),
                                    mochaQty.getText().toString(),
                                    exQty.getText().toString(),
                                    coQty.getText().toString(),
                                    doQty.getText().toString(),
                                    txtdate.getText().toString());
                        }

                        if (isInserted = true) {
                            Toast.makeText(orderConfirmActivity.this, "Order is Confirmed", Toast.LENGTH_LONG).show();
                            Intent i = new Intent(orderConfirmActivity.this, invoiceActivity.class);
                            am = americanoQty.getText().toString();
                            la = latteQty.getText().toString();
                            mo = mochaQty.getText().toString();
                            es = exQty.getText().toString();
                            co = coQty.getText().toString();
                            doo = doQty.getText().toString();

                            i.putExtra("Value1", am);
                            i.putExtra("Value2", la);
                            i.putExtra("Value3", mo);
                            i.putExtra("Value4", es);
                            i.putExtra("Value5", co);
                            i.putExtra("Value6", doo);
                            startActivity(i);
                            finish();
                        } else
                            Toast.makeText(orderConfirmActivity.this, "Order is not Confirmed", Toast.LENGTH_LONG).show();


                    }
                }
        );
    }
}

