package com.Project.caffe_talk;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import java.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class customerRegisterActivity extends AppCompatActivity {

    EditText Name;
    EditText Phone;
    EditText Mail;
    EditText Pw01;
    ImageView Imgphoto;
    Button btnPhoto;
    Button btnlogin3;
    Button btnregister3;

    private TextView txtdate;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;

    DatabaseHelper mydb;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_register);

        mydb = new DatabaseHelper(this);
        Name = findViewById(R.id.txtname);
        Phone = findViewById(R.id.txtphone);
        Mail = findViewById(R.id.txtemail);
        Pw01 = findViewById(R.id.txtpw);
        Imgphoto = findViewById(R.id.imgphoto);
        btnPhoto = findViewById(R.id.btnphoto);
        btnlogin3 = findViewById(R.id.btnlogin3);
        btnregister3 = findViewById(R.id.btnregister2);

        txtdate = (TextView) findViewById(R.id.txtdate);

        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        date = dateFormat.format(calendar.getTime());
        txtdate.setText(date);

        AddData();

        btnlogin3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent myInteent= new Intent(getBaseContext(),customerLoginActivity.class);
                startActivity(myInteent);
            }
        });




        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }





        btnPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImageFromCamera();

            }
        });


    }
    void captureImageFromCamera(){
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent,0);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap cameraImageData = (Bitmap) data.getExtras().get("data");
        Imgphoto.setImageBitmap(cameraImageData);
    }
    public void AddData()
    {
        btnregister3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        final String name = Name.getText().toString();
                        final String tel = Phone.getText().toString();
                        final String email = Mail.getText().toString();
                        final String pwd = Pw01.getText().toString();

                        if (name.length() == 0) {
                            Name.requestFocus();
                            Name.setError("NAME CANNOT BE EMPTY");
                        }
                        else if (!name.matches("[a-zA-Z ]+")) {
                            Name.requestFocus();
                            Name.setError("ENTER ONLY ALPHABETICAL CHARACTER");
                        }
                        else if (tel.length() == 0) {
                            Phone.requestFocus();
                            Phone.setError("CONTACT NO CANNOT BE EMPTY");
                        }
                        else if (!tel.matches("[0-9]+")) {
                            Phone.requestFocus();
                            Phone.setError("ENTER ONLY NUMBERS");
                        }
                        else if (!tel.matches("[0-9]+"))
                        {
                            Phone.requestFocus();
                            Phone.setError("ENTER ONLY NUMBERS");
                        }
                        else if (email.length() == 0)
                        {
                            Mail.requestFocus();
                            Mail.setError("EMAIL CANNOT BE EMPTY");
                        } else if (pwd.length() == 0)
                        {
                            Pw01.requestFocus();
                            Pw01.setError("PASSWORD CANNOT BE EMPTY");
                        }
                        else {
                            boolean send;
                            mydb.submitData(
                                    Name.getText().toString(),
                                    Phone.getText().toString(),
                                    Mail.getText().toString(),
                                    Pw01.getText().toString(),
                                    Imgphoto.getImageMatrix().toString(),
                                    txtdate.getText().toString());
                            if (send = true)
                                Toast.makeText(customerRegisterActivity.this, "Register Succesfully", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(customerRegisterActivity.this, "Register Failed", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    //private String ImgphotoToByte(ImageView image) {
    //Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
    //ByteArrayOutputStream stream = new ByteArrayOutputStream();
    //bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
    //byte[] byteArray = stream.toByteArray();
    // return byteArray ;
    //}


}
