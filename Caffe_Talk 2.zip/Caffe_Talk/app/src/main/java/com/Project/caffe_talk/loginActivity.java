package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class loginActivity extends AppCompatActivity {

    Button btnadmin;
    Button btncus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnadmin = findViewById(R.id.btnadmin);
        btncus = findViewById(R.id.btncus);

        btnadmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent1= new Intent(getBaseContext(),adminLoginActivity.class);
                startActivity(myIntent1);
            }
        });
        btncus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent myIntent2= new Intent(getBaseContext(),customerLoginActivity.class);
               startActivity(myIntent2);
            }
        });

    }
}
